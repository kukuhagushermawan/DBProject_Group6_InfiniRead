<?php
// logout.php (root)

require_once __DIR__ . '/backend/controllers/AuthController.php';

AuthController::logout();
