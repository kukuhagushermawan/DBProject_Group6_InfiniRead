document.addEventListener('DOMContentLoaded', () => {
  const provSelect = document.getElementById('province');
  const citySelect = document.getElementById('city');

  // bukan halaman yang pakai province-city
  if (!provSelect || !citySelect) return;

  // ===============================
  // Render dropdown city
  // ===============================
  function renderCityOptions(cities, selectedId = '') {
    citySelect.innerHTML = '<option value="">Pilih City</option>';

    if (!Array.isArray(cities) || cities.length === 0) {
      citySelect.innerHTML =
        '<option value="">Belum ada City</option>';
      citySelect.disabled = true;
      return;
    }

    cities.forEach(c => {
      const opt = document.createElement('option');
      opt.value = c.City_ID;
      opt.textContent = c.City_Name;

      if (String(c.City_ID) === String(selectedId)) {
        opt.selected = true;
      }

      citySelect.appendChild(opt);
    });

    citySelect.disabled = false;
  }

  // ===============================
  // Load city dari backend
  // ===============================
  async function loadCities(provinceId, selectedCityId = '') {
    if (!provinceId) {
      citySelect.innerHTML =
        '<option value="">Pilih Province terlebih dahulu</option>';
      citySelect.disabled = true;
      return;
    }

    citySelect.disabled = true;
    citySelect.innerHTML =
      '<option value="">Memuat data city...</option>';

    try {
      const url =
        '/backend/api/cities.php?province_id=' +
        encodeURIComponent(provinceId);

      const res = await fetch(url, {
        method: 'GET',
        headers: {
          'Accept': 'application/json'
        }
      });

      if (!res.ok) {
        throw new Error('HTTP status ' + res.status);
      }

      // 🔴 PENTING: pastikan response JSON
      const text = await res.text();
      let data;

      try {
        data = JSON.parse(text);
      } catch (e) {
        console.error('Response bukan JSON:', text);
        throw new Error('Invalid JSON response');
      }

      // kalau backend balikin error object
      if (!Array.isArray(data)) {
        console.error('Format data salah:', data);
        throw new Error('Data bukan array');
      }

      renderCityOptions(data, selectedCityId);

    } catch (err) {
      console.error('Gagal load cities:', err);
      citySelect.innerHTML =
        '<option value="">Gagal memuat city</option>';
      citySelect.disabled = true;
    }
  }

  // ===============================
  // Event change province
  // ===============================
  provSelect.addEventListener('change', () => {
    const provId = provSelect.value;
    loadCities(provId, '');
  });

  // ===============================
  // Auto-load (register / profile edit)
  // ===============================
  const oldProv =
    window._oldProvince || provSelect.value || '';
  const oldCity =
    window._oldCity || '';

  if (oldProv) {
    loadCities(oldProv, oldCity);
  } else {
    citySelect.innerHTML =
      '<option value="">Pilih Province terlebih dahulu</option>';
    citySelect.disabled = true;
  }
});
