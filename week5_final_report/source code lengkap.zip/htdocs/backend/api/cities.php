<?php
// backend/api/cities.php

require_once __DIR__ . '/../config/database.php';
require_once __DIR__ . '/../models/City.php';

header('Content-Type: application/json; charset=utf-8');

$province_id = isset($_GET['province_id'])
    ? (int) $_GET['province_id']
    : 0;

if ($province_id <= 0) {
    echo json_encode([]);
    exit;
}

try {
    $cities = City::byProvince($province_id);
    echo json_encode($cities);
} catch (Throwable $e) {
    http_response_code(500);
    echo json_encode([]);
}
