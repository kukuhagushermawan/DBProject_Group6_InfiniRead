<?php
// htdocs/backend/controllers/OverdueController.php

require_once __DIR__ . '/../config/database.php';

/**
 * Jalankan update status BORROWED -> OVERDUE
 * jika sudah lewat Due_Date dan Return_Date masih NULL.
 */
function runOverdueChecker(mysqli $mysqli): void
{
    // Due_Date, Return_Date, Brw_Status, table: borrowing
    $sql = "
        UPDATE borrowing
        SET Brw_Status = 'OVERDUE'
        WHERE Brw_Status = 'BORROWED'
          AND Return_Date IS NULL
          AND Due_Date < CURDATE()
    ";

    $mysqli->query($sql);
}
